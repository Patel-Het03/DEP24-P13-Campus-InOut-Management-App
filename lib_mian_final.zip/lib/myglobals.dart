library myglobals;

import "package:my_gate_app/notifier.dart";

AuthState? auth;

bool loadSplash=true;
